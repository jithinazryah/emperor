
<?= $form->field($model, 'first_line_ashore')->textInput(['tabindex' => 10]) ?>

<?= $form->field($model, 'all_fast')->textInput(['tabindex' => 11]) ?>

<?= $form->field($model, 'gangway_down')->textInput(['tabindex' => 12]) ?>

<?= $form->field($model, 'pilot_away')->textInput(['tabindex' => 6]) ?>

<?= $form->field($model, 'customs_clearance_obtained')->textInput(['tabindex' => 11]) ?>

<?= $form->field($model, 'hoses_connected')->textInput(['tabindex' => 16]) ?>

<?= $form->field($model, 'pre_discharge_safety')->textInput(['tabindex' => 20]) ?>

<?= $form->field($model, 'surveyor_on_board')->textInput(['tabindex' => 7]) ?>

<?= $form->field($model, 'sampling')->textInput(['tabindex' => 12]) ?>

<?= $form->field($model, 'cargo_commenced')->textInput(['tabindex' => 16]) ?>

<?= $form->field($model, 'cargo_completed')->textInput(['tabindex' => 17]) ?>

<?= $form->field($model, 'tank_inspection_completed')->textInput(['tabindex' => 17]) ?>

<?= $form->field($model, 'hoses_disconnected')->textInput(['tabindex' => 21]) ?>

<?= $form->field($model, 'customs_clearance_obtained')->textInput(['tabindex' => 17]) ?>  

<?= $form->field($model, 'lastline_away')->textInput(['tabindex' => 19]) ?>

<?= $form->field($model, 'cleared_channel')->textInput(['tabindex' => 20]) ?>

<?= $form->field($model, 'pob_outbound')->textInput(['tabindex' => 18]) ?>

<?= $form->field($model, 'sbe')->textInput(['tabindex' => 8]) ?>

<?= $form->field($model, 'cosp')->textInput(['tabindex' => 21]) ?>

<?= $form->field($model, 'eta_next_port')->textInput(['tabindex' => 23]) ?>