<?= $form->field($model, 'dropped_anchor')->textInput(['tabindex' => 6]) ?>

<?= $form->field($model, 'all_fast')->textInput(['tabindex' => 11]) ?>

<?= $form->field($model, 'cargo_commenced')->textInput(['tabindex' => 16]) ?>

<?= $form->field($model, 'cleared_channel')->textInput(['tabindex' => 20]) ?>

<?= $form->field($model, 'anchor_aweigh')->textInput(['tabindex' => 7]) ?>

<?= $form->field($model, 'gangway_down')->textInput(['tabindex' => 12]) ?>

<?= $form->field($model, 'cargo_completed')->textInput(['tabindex' => 17]) ?>

<?= $form->field($model, 'cosp')->textInput(['tabindex' => 21]) ?>


<?= $form->field($model, 'arrived_pilot_station')->textInput(['tabindex' => 8]) ?>

<?= $form->field($model, 'agent_on_board')->textInput(['tabindex' => 13]) ?>

<?= $form->field($model, 'pob_outbound')->textInput(['tabindex' => 18]) ?>

<?= $form->field($model, 'fasop')->textInput(['tabindex' => 22]) ?>

<?= $form->field($model, 'pob_inbound')->textInput(['tabindex' => 9]) ?>

<?= $form->field($model, 'immigration_commenced')->textInput(['tabindex' => 14]) ?>

<?= $form->field($model, 'cast_off')->textInput(['tabindex' => 18]) ?>

<?= $form->field($model, 'eta_next_port')->textInput(['tabindex' => 23]) ?>

<?= $form->field($model, 'first_line_ashore')->textInput(['tabindex' => 10]) ?>

<?= $form->field($model, 'immigartion_completed')->textInput(['tabindex' => 15]) ?>

<?= $form->field($model, 'lastline_away')->textInput(['tabindex' => 19]) ?>

<div class="form-group "></div>


