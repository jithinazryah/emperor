<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">FIRST LINE ASHORE  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->first_line_ashore) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">ALL FAST  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->all_fast) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">GANGWAY DOWN  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->gangway_down) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">PILOT AWAY  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->pilot_away) ?>
    <?= $$newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">CUSTOMS CLEARANCE OBTAINED :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->customs_clearance_obtained) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">HOSES CONNECTED :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->hoses_connected) ?>
    <?= $newDate; ?>
    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">PRE DISCHARGE SAFETY  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->pre_discharge_safety) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">SURVEYOR ON BOARD  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->surveyor_on_board) ?>
    <?= $$newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">SAMPLING :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->sampling) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">CARGO COMMENCED  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->cargo_commenced) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">CARGO COMPLETED  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->cargo_completed) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">TANK INSPECTION COMPLETED  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->tank_inspection_completed) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">HOSES DISCONNECTED  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->hoses_disconnected) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">CUSTOMS CLEARANCE OBTAINED  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->customs_clearance_obtained) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>

<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">LASTLINE AWAY  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->lastline_away) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">CLEARED CHANNEL  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->cleared_channel) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">POB OUTBOUND  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->pob_outbound) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">SBE  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->sbe) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">COSP  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->cosp) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">ETA NEXT PORT  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->eta_next_port) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
