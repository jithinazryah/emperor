<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">FIRST LINE ASHORE  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->first_line_ashore) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">ALL FAST  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->all_fast) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">CARGO COMMENCED  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->cargo_commenced) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">CARGO COMPLETED  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->cargo_completed) ?>
    <?= $$newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">POB OUTBOUND  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->pob_outbound) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">CAST OFF  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->cast_off) ?>
    <?= $newDate; ?>
    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">LASTLINE AWAY  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->lastline_away) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">CLEARED CHANNEL  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->cleared_channel) ?>
    <?= $$newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">COSP  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->cosp) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">FASOP  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->fasop) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">ETA NEXT PORT  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($ports->eta_next_port) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
