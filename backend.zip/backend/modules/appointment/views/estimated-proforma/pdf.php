<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title></title>
    </head>
    <body>
        <div style="margin-left: 75px;margin-right: 10px;margin-top: 25px;margin-bottom: 15px;">
            <div class="header">
                <div class="left">
                    <img src="images/logoleft.jpg"/>
                </div>
                <div class="right">
                    <img src="images/logoright.jpg"/>
                </div>
            </div>
        </div>
        <div style="margin-left: 75px;margin-right: 25px">
            <table>
                <tr>
                    <td style="width: 250px;"><b>To:</b> Azhrya Network Azhrya Network Azhrya Network</td>
                    <td style="width: 250px;"></td>
                    <td style="width: 250px;"></td>
                    <td style="width: 250px;"><b>Date:</b>13/08/2016</td>
                </tr>
                <tr>
                    <td style="width: 250px;"></td>
                    <td style="width: 250px;"></td>
                    <td style="width: 200px;"></td>
                    <td style="width: 250px;"><b>Client Code:</b>IPC</td>
                </tr>
                <tr><td colspan="4"></td></tr>
                <tr><td colspan="4"></td></tr>
                <tr><td colspan="4"></td></tr>
                <tr><td colspan="4"></td></tr>
                <tr>
                    <td colspan="4" style="text-align: center;"><b>ESTIMATED PORT COST ESTIMATE</b></td>
                </tr>
                <tr><td colspan="4"></td></tr>
                <tr><td colspan="4"></td></tr>
                <tr><td colspan="4"></td></tr>
                <tr><td colspan="4"></td></tr>
                <tr>
                    <td style="width: 250px;"><b>Port:</b></td>
                    <td style="width: 250px;"><b>Vessel:</b></td>
                    <td style="width: 250px;"></td>
                    <td style="width: 250px;"><b>Ref: No</b></td>
                </tr>
                <tr><td colspan="4"></td></tr>
                <tr><td colspan="4"></td></tr>
                <tr>
                    <td style="width: 250px;"><b>ETA:</b></td>
                    <td style="width: 250px;"><b>Purpose:</b></td>
                    <td style="width: 250px;"></td>
                    <td style="width: 250px;"><b>Ops No: No</b></td>
                </tr>
                <tr><td colspan="4"></td></tr>
                <tr><td colspan="4"></td></tr>
                <tr>
                    <td style="width: 250px;"><b>Details:</b></td>
                    <td style="width: 250px;"></td>
                    <td style="width: 250px;"></td>
                    <td style="width: 250px;"></td>
                </tr>
            </table> 
            <br/>

            <form>
                <table width="1000" border="1">
                    <tr>
                        <td colspan="2">Service Category</td>
                        <td rowspan="2">Unit Tons/No</td>
                        <td rowspan="2"><b>Comments</b></td>
                        <td rowspan="2">Unit Price</td>
                        <td>Amount</td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>Comments/Rate to category</td>
                        <td>AED</td>

                    </tr>
                </table>

            </form>


            <h6>Port Charges</h6>

            <table width="1000" border="1">
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="5" style="text-align: center;">Sub total:</td>
                    <td>AED125</td>
                </tr>
            </table>

            <h6>Vessel Expenses</h6>
            <table width="1000" border="1">
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="5" style="text-align: center;">Sub total:</td>
                    <td>AED125</td>
                </tr>
            </table>
            <h6>Agency Charges</h6>
            <table width="1000" border="1">
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="5" style="text-align: center;">Sub total:</td>
                    <td>AED125</td>
                </tr>
            </table>
            <br/>
            <table width="1000" border="1">
                <tr>
                    <td><b>Grand Total Estimate</b></td>
                    <td colspan="3"></td>
                    <td>USD 123456</td>
                    <td>AED 456737</td>
                </tr>
            </table>
            <br/>
            <p class="ptittle"><i>- Additional scope of work other than mentioned in the tarrif to be mutually agreed between two parties prior initiation of service.</i></p>
            <p class="pcontent"><b>
                    Please note that this is a pro-forma disbursement account only. It is intended to be an estimate of the actual disbursement account and is for guidance purposes only. 
                    Whilst Emperor Shipping Lines does take every care to ensure that the figures and information contained in the pro-forma disbursement account are as accurate as possibles
                    ,the actual disbursement account may, and often does, for various reasons beyond our control, vary from the pro-forma disbursement account. 
                </b>
            </p>

            <p class="pcontent">
                <b>
                    This duty exists regardless of any difference between the figures in this pro-forma disbursement account and the actual disbursement account.
                </b>
            </p>
            <p class="pcontent">
                <b>
                    To facilitate easy tracking, please include the ref number, vessel name & ETA on remittance advices and all correspondence.
                    This will reduce the chance of delays due to mis-identification of funds
                </b>
            </p>

            <p class="pcontent">
                All services from Thirdy Party Service Providers are performed in accordance with the relevant service providers Standard Trading Terms & Conditions,
                which a copy can be obtained on request from our office.
            </p>

            <p class="pcontent">
                All services are performed in accordance with the ESL Standard Trading Terms & Conditions which can be viewed at www.emperor.ae and a copy
                of which is available on request.
            </p>

            <p class="ptittle">Bank Details</p>

            <div class="container">
                <div class="dt1">
                    <form>
                        <table width="300">
                            <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>NAME </td>
                                <td>:emperor</td>
                            </tr>
                            <tr>
                                <td>A/C NO</td>
                                <td>:4155663</td>
                            </tr>
                            <tr>
                                <td>IBAN</td>
                                <td>:125478996</td>
                            </tr>
                            <tr>
                                <td>SWIFT</td>
                                <td>:address</td>
                            </tr>
                            <tr>
                                <td>BRANCH</td>
                                <td>:branch name</td>
                            </tr>
                        </table>

                    </form>
                </div>
                <div class="dt2">
                    <form>
                        <table width="300" border="1">
                            <caption style="text-align: left; font-size: 12px;">Sign & Stamp</caption>
                            <tr class="hei">
                                <td>&nbsp;</td>
                            </tr>
                        </table>

                    </form>
                </div>
            </div>
            <div class="footer">
                <span>
                    <p>
                        Emperor Shipping Lines LLC, P.O.Box-328231, Saqr Port, Al Shaam, Ras Al Khaimah, UAE
                        Tel: +971 7 268 9676 / Fax: +917 7 268 9677
                        www.emperor.ae
                    </p>
                </span>
            </div>

        </div>
        <?php
        // put your code here
        ?>
    </body>
</html>
